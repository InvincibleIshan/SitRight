# SitRight Store

SitRight is an ergonomic cushion and posture improvement product line, founded by **Ishan** with 25+ years in ergonomics.
Tanush and Vashisht also played key roles in building the company.

This website is styled in an **Amazon-like layout** with SitRight branding.
It supports:
- Product pages for SitRight Premium, SitRight Basic, and SitRight App subscription
- Add to Cart, View Cart, and Checkout
- Order history with Buy Again option
- Sign-in / Create account stored in `localStorage`

## How to Publish on GitHub Pages

1. Create a new **public repository** on your GitHub account (e.g., `sitright`).
2. Upload the files from this ZIP **directly into the root** of the repository.
3. Go to **Settings → Pages**.
4. Under *Source*, select **Deploy from a branch**.
5. Set branch to `main` and folder to `/ (root)`, then click **Save**.
6. Wait 1–2 minutes, and your site will be live at:
   ```
   https://yourusername.github.io/sitright/
   ```

Enjoy your free online SitRight store!
